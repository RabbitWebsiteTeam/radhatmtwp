<?php defined('ABSPATH') or die("No script kiddies please!"); ?>
<div  class="smls-upgrade-wrapper">
    <img src="<?php echo SMLS_IMG_DIR; ?>/upgrade-250.jpg" alt="<?php _e('Upgrade Smart Logo Showcase', SMLS_TD); ?>">
    <div class="smls-upgrade-button-wrap-backend">
        <a href="http://demo.accesspressthemes.com/wordpress-plugins/smart-logo-showcase/" class="smls-demo-btn" target="_blank">Demo</a>
        <a href="https://codecanyon.net/item/smart-logo-showcase-responsive-clients-logo-gallery-plugin-for-wordpress/19274075?ref=AccessKeys" target="_blank" class="smls-upgrade-btn">Upgrade</a>
        <a href="https://accesspressthemes.com/wordpress-plugins/smart-logo-showcase/" target="_blank" class="smls-upgrade-btn">Plugin Information</a>
    </div>
</div>
