<div id='nextgen_pro_upgrade_page' class="wrap about-wrap">
    <h1><?php esc_html_e($i18n->plus_title); ?></h1>
    <p class="about-text">
        <?php esc_html_e($i18n->plus_desc_first); ?><br>
        <a href='https://www.imagely.com/wordpress-gallery-plugin/nextgen-pro/?utm_source=ngg&utm_medium=ngguser&utm_campaign=ngpro' target='_blank' class="button-primary"><?php esc_html_e($i18n->plus_button); ?></a><br>
        <span><?php esc_html_e($i18n->video); ?></span>
        </p>

    <div class="feature-section">
        <iframe src="https://www.youtube.com/embed/zmA-b_jiXN0" frameborder="0" allowfullscreen></iframe>
    </div>
</div>
